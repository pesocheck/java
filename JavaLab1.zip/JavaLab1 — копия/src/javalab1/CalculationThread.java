/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javalab1;


import javax.swing.table.DefaultTableModel;
import javax.swing.SwingUtilities;

/**
 * Класс-задача для вычисления интеграла в отдельном потоке.
 */
public class CalculationThread implements Runnable {
    private final RecIntegral rec;
    private final DefaultTableModel model;
    private final int rowIndex;

    public CalculationThread(RecIntegral rec, DefaultTableModel model, int rowIndex) {
        this.rec = rec;
        this.model = model;
        this.rowIndex = rowIndex;
    }

    @Override
    public void run() {
        // 1. Выполняем "тяжелое" вычисление в фоновом потоке
        rec.calculate();

        // 2. Обновляем таблицу через invokeLater, 
        // чтобы не вызвать зависание или ошибку интерфейса
        SwingUtilities.invokeLater(() -> {
            model.setValueAt(rec.getResult(), rowIndex, 3);
        });
    }

}
